cd pycdc
cmake -S .
make
